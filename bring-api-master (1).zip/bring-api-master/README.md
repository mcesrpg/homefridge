# bring-api
Incomplete, reverse-engineered and unofficial Bring! API

### Credits
Reverse Engineering   by helvet003<br/>
PHP version   by helvet003<br/>
Example: https://twitter.com/HelveteD/status/836262765719347202

Python version  by philipp2310<br/>
Used in ProjectAlice voice assistant: https://github.com/project-alice-assistant/ProjectAliceSkills

Node version by foxriver76<br/>
https://github.com/foxriver76/node-bring-api
